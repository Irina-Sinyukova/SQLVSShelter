﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;

namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для Dogs.xaml
    /// </summary>
    public partial class Dogs : Page
    {
        private static ShelterEntities _context = new ShelterEntities();
        public Dogs()
        {
            InitializeComponent();
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
        }

        private void BtnEditDog_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new EditDog((sender as Button).DataContext as Dogs));
        }
    }
}
