﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDogs.xaml
    /// </summary>
    public partial class PageDogs : Page
    {
        private static ShelterEntities _context = new ShelterEntities();
        public PageDogs()
        {
            InitializeComponent();
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();

            CmbFiltrProv.ItemsSource = ShelterEntities.GetContext().Guardians.ToList();
            CmbFiltrProv.SelectedValuePath = "idGuard";
            CmbFiltrProv.DisplayMemberPath = "FirstName";
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                ShelterEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditDogs((sender as Button).DataContext as Dogs));
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditDogs(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var DogForRemoving = DGridDog.SelectedItems.Cast<Dogs>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {DogForRemoving.Count()} данную собаку?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ShelterEntities.GetContext().Dogs.RemoveRange(DogForRemoving);
                    ShelterEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.Where(x => x.Nickname.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.OrderBy(x => x.Age).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.OrderByDescending(x => x.Age).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
        }

        private void CmbFiltrProv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrProv.SelectedIndex + 1;
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.Where(x => x.FK_Guardians == id).ToList();
        }

        private void BtnShelter_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageShelters((sender as Button).DataContext as Shelters));
        }

        private void BtnGuardian_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageGuardians((sender as Button).DataContext as Guardians));
        }

        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Кличка";
            worksheet.Cells[3][indexRows] = "Возраст";
            worksheet.Cells[4][indexRows] = "Порода";
            worksheet.Cells[5][indexRows] = "Вес";
            worksheet.Cells[6][indexRows] = "Опекун";

            var printItems = DGridDog.Items;

            foreach (Dogs item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.Nickname;
                worksheet.Cells[3][indexRows + 1] = item.Age;
                worksheet.Cells[4][indexRows + 1] = item.Breed;
                worksheet.Cells[5][indexRows + 1] = item.Weight;
                worksheet.Cells[6][indexRows + 1].Value = item.Guardians.ToString();

                indexRows++;
            }
            Excel.Range range = worksheet.Range[worksheet.Cells[2][indexRows + 1],
                    worksheet.Cells[6][indexRows + 1]];
            range.ColumnWidth = 30;
            range.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            app.Visible = true;
        }
    }
}
