﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;

namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDogs.xaml
    /// </summary>
    public partial class PageDogs : Page
    {
        private static ShelterEntities _context = new ShelterEntities();
        public PageDogs()
        {
            InitializeComponent();
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();

            CmbFiltrProv.ItemsSource = ShelterEntities.GetContext().Guardians.ToList();
            CmbFiltrProv.SelectedValuePath = "idGuard";
            CmbFiltrProv.DisplayMemberPath = "FirstName";
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                ShelterEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditDogs((sender as Button).DataContext as Dogs));
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditDogs(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var DogForRemoving = DGridDog.SelectedItems.Cast<Dogs>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {DogForRemoving.Count()} данный продукт?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ShelterEntities.GetContext().Dogs.RemoveRange(DogForRemoving);
                    ShelterEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.Where(x => x.Nickname.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.OrderBy(x => x.Nickname).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.OrderByDescending(x => x.Nickname).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
        }

        private void CmbFiltrProv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrProv.SelectedIndex + 1;
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.Where(x => x.FK_Guardians == id).ToList();
        }
    }
}
