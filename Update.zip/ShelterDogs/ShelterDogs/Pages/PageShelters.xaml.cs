﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;

namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageShelters.xaml
    /// </summary>
    public partial class PageShelters : Page
    {
        private static ShelterEntities _context = new ShelterEntities();
        public PageShelters()
        {
            InitializeComponent();
            DGridShelter.ItemsSource = ShelterEntities.GetContext().Shelters.ToList();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var productForRemoving = DGridShelter.SelectedItems.Cast<Shelters>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {productForRemoving.Count()} данный продукт?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ShelterEntities.GetContext().Shelters.RemoveRange(productForRemoving);
                    ShelterEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridShelter.ItemsSource = ShelterEntities.GetContext().Shelters.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
