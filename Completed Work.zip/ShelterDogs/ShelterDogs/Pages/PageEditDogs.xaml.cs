﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;

namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageEditDogs.xaml
    /// </summary>
    public partial class PageEditDogs : Page
    {
        private Dogs _currentDogs = new Dogs();

        public PageEditDogs(Dogs selectedDogs)
        {
            InitializeComponent();
            if (selectedDogs != null)
                _currentDogs = selectedDogs;
            DataContext= _currentDogs;
            
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentDogs.Nickname))
                error.AppendLine("Укажите кличку");

            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }

            if(_currentDogs.idDog == 0)
                ShelterEntities.GetContext().Dogs.Add( _currentDogs );
            try
            {
                ShelterEntities.GetContext().SaveChanges();
                MessageBox.Show("Новая собака добавлена");
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
                
            
        }
    }
}
