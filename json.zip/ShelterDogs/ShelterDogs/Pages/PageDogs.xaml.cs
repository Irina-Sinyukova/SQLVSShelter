﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Newtonsoft.Json;



namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDogs.xaml
    /// </summary>
    public partial class PageDogs : Page
    {
        private static ShelterEntities _context = new ShelterEntities();
        public PageDogs()
        {
            InitializeComponent();
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();

            CmbFiltrProv.ItemsSource = ShelterEntities.GetContext().Guardians.ToList();
            CmbFiltrProv.SelectedValuePath = "idGuard";
            CmbFiltrProv.DisplayMemberPath = "FirstName";
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                ShelterEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditDogs((sender as Button).DataContext as Dogs));
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditDogs(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var DogForRemoving = DGridDog.SelectedItems.Cast<Dogs>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {DogForRemoving.Count()} данную собаку?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ShelterEntities.GetContext().Dogs.RemoveRange(DogForRemoving);
                    ShelterEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.Where(x => x.Nickname.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.OrderBy(x => x.Age).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.OrderByDescending(x => x.Age).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
        }

        private void CmbFiltrProv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrProv.SelectedIndex + 1;
            DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.Where(x => x.FK_Guardians == id).ToList();
        }

        private void BtnShelter_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageShelters((sender as Button).DataContext as Shelters));
        }

        private void BtnGuardian_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageGuardians((sender as Button).DataContext as Guardians));
        }

        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 5;
            worksheet.Cells[2, 2] = "Собаки, зарегестрированные в приютах:";
            worksheet.Cells[4, 1] = DateTime.Now.ToString();
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Кличка";
            worksheet.Cells[3][indexRows] = "Возраст";
            worksheet.Cells[4][indexRows] = "Порода";
            worksheet.Cells[5][indexRows] = "Вес";

            Excel.Range Bold = worksheet.Range[worksheet.Cells[1]
            [indexRows], worksheet.Cells[5][indexRows]];
            Bold.Font.Bold = worksheet.Cells[1][indexRows].Font.Bold = true;
            Excel.Range Borders = worksheet.Range[worksheet.Cells[1][5], worksheet.Cells[5][15]];
            Borders.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
            Borders.ColumnWidth = 10;


            var printItems = DGridDog.Items;

            foreach (Dogs item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.Nickname;
                worksheet.Cells[3][indexRows + 1] = item.Age;
                worksheet.Cells[4][indexRows + 1] = item.Breed;
                worksheet.Cells[5][indexRows + 1] = item.Weight;

                indexRows++;
            }
            Excel.Range range = worksheet.Range[worksheet.Cells[2][indexRows + 1],
                    worksheet.Cells[6][indexRows + 1]];
            range.ColumnWidth = 10;
            range.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            worksheet.Cells[indexRows + 2, 3] = "Подпись:";
            worksheet.Cells[indexRows + 2, 5] = "Синюкова И.А.";

            app.Visible = true;
            
        }

        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            int num = DGridDog.Items.Count;
            MessageBox.Show("Всего собак:" + num);
        }

        private void BtnSaveJson_Click(object sender, RoutedEventArgs e)
        {
            File.WriteAllText("input.json", string.Empty);
            foreach (var nt in ShelterEntities.GetContext().Dogs)
            {
                Dogs dogs = new Dogs()
                {
                    Nickname = nt.Nickname,
                    Age = nt.Age,
                    Breed = nt.Breed,
                    Finding = nt.Finding,
                    Weight = nt.Weight
                };
                File.WriteAllText("input.json", JsonConvert.SerializeObject(dogs));
            }
                

        }

        private void BtnSearchJson_Click(object sender, RoutedEventArgs e)
        {
            List<Dogs> dog = new List<Dogs>();//Список записок
            JsonTextReader reader = new JsonTextReader(new StreamReader("input.json"));//Открытие файла
            reader.SupportMultipleContent = true;
            while (reader.Read())//Пока не закончатся записи
            {
                JsonSerializer serializer = new JsonSerializer();
                Dogs temp_point = serializer.Deserialize<Dogs>(reader); // 1 записка
                if (temp_point.Breed.Contains(TxtSearchJson.Text)) //Отображение по совпадению с поиском
                    dog.Add(temp_point);

                DGridDog.ItemsSource = dog;
                if (TxtSearchJson.Text == string.Empty)
                    DGridDog.ItemsSource = ShelterEntities.GetContext().Dogs.ToList();
                
            }
        }
    }
}