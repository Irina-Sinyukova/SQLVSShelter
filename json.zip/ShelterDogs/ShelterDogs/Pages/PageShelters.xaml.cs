﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;

namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageShelters.xaml
    /// </summary>
    public partial class PageShelters : Page
    {
        public Shelters _currentShelters = new Shelters();

        private static ShelterEntities _context = new ShelterEntities();
        public PageShelters(Shelters selectedShelters)
        {
            InitializeComponent();
            if (selectedShelters != null)
                _currentShelters = selectedShelters;
            DataContext = _currentShelters;

            DGridShelter.ItemsSource = ShelterEntities.GetContext().Shelters.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditShelter((sender as Button).DataContext as Shelters));
        }

        private void Page_IsVisibleChanged1(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                ShelterEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridShelter.ItemsSource = ShelterEntities.GetContext().Shelters.ToList();
            }
        }

        private void btnAddShelters_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditShelter(null));
        }

        private void btnDeleteShelter_Click(object sender, RoutedEventArgs e)
        {
            var ShelterForRemoving = DGridShelter.SelectedItems.Cast<Shelters>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {ShelterForRemoving.Count()} данный приют?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ShelterEntities.GetContext().Shelters.RemoveRange(ShelterForRemoving);
                    ShelterEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridShelter.ItemsSource = ShelterEntities.GetContext().Shelters.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void TxbSearchCity_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridShelter.ItemsSource = ShelterEntities.GetContext().Shelters.Where(x => x.City.ToLower().Contains(TxbSearchCity.Text.ToLower())).ToList();
        }
    }
}
