﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;

namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageEditShelter.xaml
    /// </summary>
    public partial class PageEditShelter : Page
    {
        private Shelters _currentShelters = new Shelters();
        public PageEditShelter(Shelters selectedShelters)
        {
            InitializeComponent();
            if (selectedShelters != null)
                _currentShelters = selectedShelters;
            DataContext = _currentShelters;
        }

        private void BtnSaveShelters_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentShelters.Type))
                error.AppendLine("Укажите кличку");

            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }

            if (_currentShelters.idShelt == 0)
                ShelterEntities.GetContext().Shelters.Add(_currentShelters);
            try
            {
                ShelterEntities.GetContext().SaveChanges();
                MessageBox.Show("Новый приют добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
