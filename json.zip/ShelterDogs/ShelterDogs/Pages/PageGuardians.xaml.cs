﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;

namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageGuardians.xaml
    /// </summary>
    public partial class PageGuardians : Page
    {
        public Guardians _currentGuardians = new Guardians();

        private static ShelterEntities _context = new ShelterEntities();
        public PageGuardians(Guardians selectedGuardians)
        {
            InitializeComponent();
            if (selectedGuardians != null)
                _currentGuardians = selectedGuardians;
            DataContext = _currentGuardians;

            DGridGuardians.ItemsSource = ShelterEntities.GetContext().Guardians.ToList();
        }

        private void Page_IsVisibleChanged1(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                ShelterEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridGuardians.ItemsSource = ShelterEntities.GetContext().Guardians.ToList();
            }
        }

        private void BtnEditGuard_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditGuardians((sender as Button).DataContext as Guardians));
        }

        private void btnAddGuardians_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditGuardians(null));
        }

        private void btnDeleteGuardians_Click(object sender, RoutedEventArgs e)
        {
            var GuardiansForRemoving = DGridGuardians.SelectedItems.Cast<Guardians>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {GuardiansForRemoving.Count()} данного опекуна?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ShelterEntities.GetContext().Guardians.RemoveRange(GuardiansForRemoving);
                    ShelterEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridGuardians.ItemsSource = ShelterEntities.GetContext().Guardians.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void TxbSearchLastName_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridGuardians.ItemsSource = ShelterEntities.GetContext().Guardians.Where(x => x.LastName.ToLower().Contains(TxbSearchLastName.Text.ToLower())).ToList();
        }
    }
}
