﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShelterDogs.Classes;

namespace ShelterDogs.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageEditGuardians.xaml
    /// </summary>
    public partial class PageEditGuardians : Page
    {
        private Guardians _currentGuardians = new Guardians();
        public PageEditGuardians(Guardians selectedGuardians)
        {
            InitializeComponent();
            if (selectedGuardians != null)
                _currentGuardians = selectedGuardians;
            DataContext = _currentGuardians;
        }

        private void BtnSaveGuardians_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentGuardians.FirstName))
                error.AppendLine("Укажите имя");

            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }

            if (_currentGuardians.idGuard == 0)
                ShelterEntities.GetContext().Guardians.Add(_currentGuardians);
            try
            {
                ShelterEntities.GetContext().SaveChanges();
                MessageBox.Show("Новый опекун добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
